package com.example.weighttrackingapp;

public class UserModel {
    private int id;
    private String date;
    private int weight;

    public UserModel(int id, String date, int weight) {
        this.id = id;
        this.date = date;
        this.weight = weight;
    }

    public UserModel() {

    }

    @Override
    public String toString() {
        return date + ' ' + weight + ' ';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }
}
