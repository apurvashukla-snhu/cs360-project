package com.example.weighttrackingapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SMSPermission extends AppCompatActivity {
     Button buttonSMS, buttonDeny;

     private static final int SMS_PERMISSION_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission);

        buttonSMS = findViewById(R.id.buttonSMS);
        buttonDeny = findViewById(R.id.denyButton);


        buttonSMS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkPermission(Manifest.permission.SEND_SMS, SMS_PERMISSION_CODE);
            }
        });
        buttonDeny.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
    }

    public void checkPermission(String permission, int requestCode)
    {
     if (ContextCompat.checkSelfPermission(SMSPermission.this, permission) == PackageManager.PERMISSION_DENIED) {
         ActivityCompat.requestPermissions(SMSPermission.this, new String[] {permission}, requestCode);
     }
    else {
         Toast.makeText(SMSPermission.this, "Permission already granted", Toast.LENGTH_SHORT).show();
     }
    }
    public void onRequestPermissionResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0]  == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(SMSPermission.this, "SMS Permission granted", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(SMSPermission.this, "SMS Permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
