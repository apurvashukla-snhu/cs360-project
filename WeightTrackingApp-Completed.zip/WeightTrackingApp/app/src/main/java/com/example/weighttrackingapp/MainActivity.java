package com.example.weighttrackingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    Button addButton, removeButton, SMSButton;
    EditText editDate, editWeight;
    ListView weightView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        addButton = findViewById(R.id.addButton);
        removeButton = findViewById(R.id.deleteButton);
        SMSButton = findViewById(R.id.SMSButton);
        editWeight = findViewById(R.id.editWeight);
        editDate = findViewById(R.id.editDate);
        weightView = findViewById(R.id.weight_list);


        Database database = new Database(MainActivity.this);
        List<UserModel> everyone = database.getEveryone();

        ArrayAdapter arrayAdapter = new ArrayAdapter<UserModel>(MainActivity.this, android.R.layout.simple_list_item_1, everyone);
        weightView.setAdapter(arrayAdapter);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                UserModel userModel;
                try {
                    userModel = new UserModel(-1, editDate.getText().toString(), Integer.parseInt(editWeight.getText().toString()));
                    Toast.makeText(MainActivity.this, userModel.toString(), Toast.LENGTH_SHORT).show();
                }
                catch (Exception e) {
                    Toast.makeText(MainActivity.this, "error", Toast.LENGTH_SHORT).show();
                    userModel = new UserModel(-1, "error", 0);
                }

                Database database;
                database = new Database(MainActivity.this);
                boolean success = database.addOne(userModel);
                Toast.makeText(MainActivity.this, "completed = " + success, Toast.LENGTH_SHORT).show();

            }
        });
        removeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UserModel userModel;
                try {
                    userModel = new UserModel(-1, editDate.getText().toString(), Integer.parseInt(editWeight.getText().toString()));
                    Toast.makeText(MainActivity.this, userModel.toString(), Toast.LENGTH_SHORT).show();
                }
                catch (Exception e) {
                    Toast.makeText(MainActivity.this, "error with entry", Toast.LENGTH_SHORT).show();
                    userModel = new UserModel(-1, "error", 0);
                }

                Database database;
                database = new Database(MainActivity.this);
                boolean success = database.removeOne(userModel);
                Toast.makeText(MainActivity.this, "removed" + success, Toast.LENGTH_SHORT).show();
            }
        });
        SMSButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), SMSPermission.class);
                startActivity(intent);
            }
        });
    }
}