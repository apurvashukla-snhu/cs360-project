package com.example.weighttrackingapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class Database extends SQLiteOpenHelper {

    public static final String WEIGHT_TABLE = "WEIGHT_TABLE";
    public static final String COLUMN_USER_DATE = "USER_DATE";
    public static final String COLUMN_USER_WEIGHT = "USER_WEIGHT";
    public static final String COLUMN_ID = "ID";

    public Database(@Nullable Context context) {
        super(context, "weight_log.db", null, 1);
    }

    // create the database when the fist addition is created
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        String createTable = "CREATE TABLE " + WEIGHT_TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_USER_DATE + " TEXT, " + COLUMN_USER_WEIGHT + " INTEGER)";

        sqLiteDatabase.execSQL(createTable);
    }


    // when the version of the application changes, this is called
    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

    }

    public boolean addOne(UserModel userModel) {

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(COLUMN_USER_DATE, userModel.getDate());
        contentValues.put(COLUMN_USER_WEIGHT, userModel.getWeight());

        long insert = sqLiteDatabase.insert(WEIGHT_TABLE, null, contentValues);
        if (insert == -1) {
            return false;
        }
        else {
            return true;
        }
    }

    public boolean removeOne(UserModel userModel) {

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.remove(COLUMN_USER_DATE);
        contentValues.remove(COLUMN_USER_WEIGHT);

        long remove = sqLiteDatabase.delete(WEIGHT_TABLE, COLUMN_ID, null);
        if (remove == -1) {
            return false;
        } else {
            return true;
        }
    }

    public List<UserModel> getEveryone() {
        List<UserModel> returnList = new ArrayList<>();

        String queryString = "SELECT * FROM " + WEIGHT_TABLE;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(queryString, null);

        if(cursor.moveToFirst()){
            do {

                int idNumber = cursor.getInt(0);
                String userDate = cursor.getString(1);
                int userWeight = cursor.getInt(2);

                UserModel newEntry = new UserModel(idNumber, userDate, userWeight);
                returnList.add(newEntry);

            } while (cursor.moveToNext());
        }
        else {

        }


        cursor.close();
        db.close();
        return returnList;
    }
}
